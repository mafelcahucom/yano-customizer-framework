<?php

/**
 * @package   Yano Customizer Framework
 * @author    Mafel John Timkang Cahucom
 * @license   https://www.gnu.org/licenses/gpl-2.0.html
 * @since     1.0
 */

namespace Control;


class Yano_Content_Editor_Control extends \WP_Customize_Control {


	/**
	 * Set if allowed media uploader
	 * @var boolean
	 */
	public $uploader;


	/**
	 * Set of toolbars to be used
	 * @var array
	 */
	public $toolbars;


	/**
	 * Returns the toolbar in imploded
	 * @return string
	 */
	private function get_toolbars() {
		$toolbars = '';
		if( ! empty( $this->toolbars ) ) {
			$toolbars = implode( ',', $this->toolbars );
		}
		return $toolbars;
	}


	/**
	 * Render the content and display in frontend
	 * @return html    control in customizer page
	 */
	public function render_content() {
	?>
	
		<div class="yano-content-editor-parent">
			<label>
				<?php if( ! empty( $this->label ) ): ?>
					<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				<?php endif; ?>

				<?php if( ! empty( $this->description ) ): ?>
				<span class="description customize-control-description"><?php echo wp_kses_post( $this->description ); ?></span>
				<?php endif; ?>
			</label>
		
			<textarea id="yano-content-editor-textarea-<?php echo esc_attr( $this->id ); ?>" 
					  class="yano-content-editor-textarea" 
					  data-toolbars="<?php echo esc_attr( $this->get_toolbars() ); ?>"
					  data-uploader="<?php echo esc_attr( $this->uploader ); ?>"
					  <?php $this->link(); ?>><?php echo esc_attr( $this->value() ); ?></textarea>
		</div>

	<?php
	}
}