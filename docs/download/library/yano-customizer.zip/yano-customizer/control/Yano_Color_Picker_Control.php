<?php

/**
 * @package   Yano Customizer Framework
 * @author    Mafel John Timkang Cahucom
 * @license   https://www.gnu.org/licenses/gpl-2.0.html
 * @since     1.0
 */

namespace Control;


class Yano_Color_Picker_Control extends \WP_Customize_Control {


	/**
	 * The type of color format return [ HSVA, HSLA, RGBA, HEXA ]
	 * @var string
	 */
	public $format;

	/**
	 * The default value
	 * @var string
	 */
	public $default;

	/**
	 * Setting for opacity
	 * @var boolean
	 */
	public $opacity;

	/**
	 * Get the default value
	 * @return string
	 */
	private function get_default() {
		if( ! empty( $this->value() ) ) {
			$output = esc_attr( $this->value() );
		}else{
			$output = 'transparent';
		}
		return $output;
	}
	
	/**
	 * Return the partial set color 
	 * @return string
	 */
	private function get_partial_color() {
		if( ! empty( $this->value() ) ) {
			$output = 'background: ' . esc_attr( $this->value() );
		}else{
			$output = 'background: transparent';
		}
		return $output;
	}

	/**
	 * Get the opacity value with validation
	 * @return number
	 */
	private function get_opacity() {
		if( ! empty( $this->opacity ) ) {
			if( $this->opacity === true ) {
				$output = 1;
			}else{
				$output = 0;
			}
		}else{
			$output = 0;
		}
		return $output;
	}

	/**
	 * Adding third party libraries
	 */
	public function enqueue() {

		// css
		if( wp_style_is( 'yano-pickr-css', 'enqueued' ) == false ){
			wp_enqueue_style( 'yano-pickr-css', yano_resource_url(). 'assets/pickr/pickr.min.css' );
		}

		// js
		if( wp_script_is( 'yano-pickr-js', 'enqueued' ) == false ){
			wp_enqueue_script( 'yano-pickr-js', yano_resource_url(). 'assets/pickr/pickr.min.js', array(), '1.0', true );
		}
	}


	/**
	 * Render the content and display in frontend
	 * @return html    control in customizer page
	 */
	public function render_content() {
	?>
		
		<label>
			<?php if( ! empty( $this->label ) ): ?>
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			<?php endif; ?>

			<?php if( ! empty( $this->description ) ): ?>
				<span class="description customize-control-description"><?php echo wp_kses_post( $this->description ); ?></span>
			<?php endif; ?>
		</label>
	
		<button class="yano-color-picker-selector" data-id="<?php echo esc_attr( $this->id ); ?>" >
			<div class="yano-color-picker-selector-color" style="background-image: url(' <?php echo yano_resource_url(); ?>assets/img/transparent.jpg ');" >
				<div id="yano-color-picker-selector-color-<?php echo esc_attr( $this->id ); ?>" style="width: 100%; height: 100%; <?php echo $this->get_partial_color(); ?>;"></div>
			</div>
			<span>Select Color</span>
		</button>
	
		<div id="yano-color-picker-parent-<?php echo esc_attr( $this->id ); ?>" class="yano-color-picker-parent">
			<input type="hidden"
				   id="yano-color-picker-input-<?php echo esc_attr( $this->id ); ?>"
				   name="<?php echo esc_attr( $this->id ); ?>"
				   value="<?php echo esc_attr( $this->value() ); ?>"
				   <?php echo $this->link(); ?>>
			
			<div id="yano-color-picker-<?php echo esc_attr( $this->id ); ?>" 
				 class="yano-color-picker"
				 data-id="<?php echo esc_attr( $this->id ); ?>"
				 data-format="<?php echo $this->format; ?>"
				 data-default="<?php echo $this->value(); ?>"
				 data-opacity="<?php echo $this->get_opacity(); ?>"></div>
		</div>

	<?php
	}
}