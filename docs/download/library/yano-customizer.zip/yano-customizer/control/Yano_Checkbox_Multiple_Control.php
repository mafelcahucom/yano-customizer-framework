<?php

/**
 * @package   Yano Customizer Framework
 * @author    Mafel John Timkang Cahucom
 * @license   https://www.gnu.org/licenses/gpl-2.0.html
 * @since     1.0
 */

namespace Control;


class Yano_Checkbox_Multiple_Control extends \WP_Customize_Control {

	/**
	 * Set of choices
	 * @var array
	 */
	public $choices;


	/**
	 * Returns the value of choices with sanitize
	 * @return array   set of choices
	 */
	private function choices_value() {

		if( ! empty( $this->choices ) ) {
			return array_unique( $this->choices );
		}
	}

	/**
	 * Returns the value is either from "default" or "value()"
	 * @return array 	the value 
	 */
	private function checked_values() {

		if( is_array( $this->value() ) ) {
			$output = $this->value();
		}else{
			$output = explode( ',', esc_attr( $this->value() ) );
		}
		return $output;
	}

	/**
	 * Render the content and display in frontend
	 * @return html    control in customizer page
	 */
	public function render_content() { 
	?>
		<label>
			<?php if( ! empty( $this->label ) ): ?>
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			<?php endif; ?>

			<?php if( ! empty( $this->description ) ): ?>
				<span class="description customize-control-description"><?php echo wp_kses_post( $this->description ); ?></span>
			<?php endif; ?>
		</label>

		<div class="yano-checkbox-multiple-parent-<?php echo esc_attr( $this->id ) ?>">

			<input type="hidden" 
				   class="yano-checkbox-multiple-input"
				   id="<?php echo esc_attr( $this->id ); ?>" 
				   name="<?php echo esc_attr( $this->id ); ?>" 
				   value="<?php echo esc_attr( $this->value() ); ?>" 
				   <?php $this->link(); ?>>
			
			<?php foreach ( $this->choices_value() as $key => $value ): ?>
					<label class="yano-checkbox-multiple-label">
						<input type="checkbox" 
						   	   class="yano-checkbox-multiple"  
						   	   name="<?php echo esc_attr( $this->id ) ?>" 
						   	   value="<?php echo esc_attr( $key ) ?>"
						   	   <?php checked( in_array( esc_attr( $key ), $this->checked_values() ), 1 ) ?>>
						<?php echo esc_attr( $value ) ?>
					</label>
			<?php endforeach; ?>	
		
		</div>
	<?php
	}
}
