<?php

/**
 * @package   Yano Customizer Framework
 * @author    Mafel John Timkang Cahucom
 * @license   https://www.gnu.org/licenses/gpl-2.0.html
 * @since     1.0
 */

namespace Control;

use Inc\Attachment\Yano_Attachment_Inc;

class Yano_Audio_Uploader_Control extends \WP_Customize_Control {


	/**
	 * List of valid extensions [ 'mp3', 'm4a', 'ogg', 'wav', 'mpg' ]
	 * 
	 * @var array
	 */
	public $extensions;

	/**
	 * Holds the placeholder
	 * @var string
	 */
	public $placeholder;


	/**
	 * Instantiating Yano_Attachment_Inc
	 * and return object attachment
	 * @return object
	 */
	private function attachment() {
		// instantiate Yano_Attachment_Inc
		$attachment = new Yano_Attachment_Inc( [
			'type'			=> 'audio',
			'id'			=> $this->id,
			'label'			=> $this->label,
			'description'	=> $this->description,
			'placeholder'	=> $this->placeholder,
			'extensions'	=> $this->extensions,
			'value'			=> $this->value()
		]);
		return $attachment;
	}


	/**
	 * Render the content and display in frontend
	 * @return html    control in customizer page
	 */
	public function render_content() {
		// render the attachment
		$this->attachment()->create();
	}
}

