<?php

/**
 * @package   Yano Customizer Framework
 * @author    Mafel John Timkang Cahucom
 * @license   https://www.gnu.org/licenses/gpl-2.0.html
 * @since     1.0
 */

namespace Control;


class Yano_Markup_Control extends \WP_Customize_Control {


	/**
	 * HTML code to be displayed in front-end
	 * @var string
	 */
	public $html;


	/**
	 * Render the content and display in frontend
	 * @return html    control in customizer page
	 */
	public function render_content() {
	?>
	
		<div class="yano-markup-parent">
			<?php echo $this->html; ?>
		</div>

	<?php
	}
}