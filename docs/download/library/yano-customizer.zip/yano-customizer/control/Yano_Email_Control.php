<?php

/**
 * @package   Yano Customizer Framework
 * @author    Mafel John Timkang Cahucom
 * @license   https://www.gnu.org/licenses/gpl-2.0.html
 * @since     1.0
 */

namespace Control;

class Yano_Email_Control extends \WP_Customize_Control {

	/**
	 * Holds placeholder
	 * @var string
	 */
	public $placeholder;


	/**
	 * Render the content and display in frontend
	 * @return html    control in customizer page
	 */
	public function render_content() {
	?>
		
		<div class="yano-email-parent">
		
			<label>
				<?php if( ! empty( $this->label ) ): ?>
					<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				<?php endif; ?>

				<?php if( ! empty( $this->description ) ): ?>
					<span class="description customize-control-description"><?php echo wp_kses_post( $this->description ); ?></span>
				<?php endif; ?>
			</label>

            <input  type="text" 
                    id="yano-email-<?php echo esc_attr( $this->id ); ?>" 
                    class="yano-email"
                    value="<?php echo esc_attr( $this->value() ); ?>" 
                    name="<?php echo esc_attr( $this->id ); ?>"
                    placeholder="<?php echo esc_attr( $this->placeholder ); ?>"
                   <?php echo $this->link(); ?>>
		</div>

	<?php
	}
}