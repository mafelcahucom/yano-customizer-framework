<?php

/**
 * @package   Yano Customizer Framework
 * @author    Mafel John Timkang Cahucom
 * @license   https://www.gnu.org/licenses/gpl-2.0.html
 * @since     1.0
 */

namespace Control;


class Yano_Tagging_Select_Control extends \WP_Customize_Control {


	/**
	 * List of choices display in option tag
	 * @var string | int
	 */
	public $choices;

	/**
	 * The maximum tag item
	 * @var integer
	 */
	public $maxitem;

	/**
	 * The placeholder of select tag
	 * @var string
	 */
	public $placeholder;


	/**
	 * Adding third party libraries
	 */
	public function enqueue() {

		// styles
		if( wp_style_is( 'yano-selectize-css', 'enqueued' ) == false ) {
			wp_enqueue_style( 'yano-selectize-css', yano_resource_url(). 'assets/selectize/selectize.css' );
		}

		// js
		if( wp_script_is( 'yano-selectize-js', 'enqueued' ) == false ) {
			wp_enqueue_script( 'yano-selectize-js', yano_resource_url(). 'assets/selectize/selectize.min.js', array(), '1.0', false );
		}
	}

	/**
	 * Finalize the max item
	 * @return integer
	 */
	private function final_max_item() {
		if( isset( $this->maxitem ) ) {
			if( is_numeric( $this->maxitem ) ) {
				$max = $this->maxitem;
			}else{
				$max = 'none';
			}
		}
		return $max;
	}


	/**
	 * Render the content and display in frontend
	 * @return html    control in customizer page
	 */
	public function render_content() {
	?>
		
		<div class="yano-tagging-select-parent">
			<label>

				<?php if( ! empty( $this->label ) ): ?>
					<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				<?php endif; ?>

				<?php if( ! empty( $this->description ) ): ?>
					<span class="description customize-control-description"><?php echo wp_kses_post( $this->description ); ?></span>
				<?php endif; ?>
				
				
			</label>

			<select class="yano-tagging-select-control" 
				 	id="<?php echo esc_attr( $this->id ) ?>" 
				 	name="<?php echo esc_attr( $this->id ) ?>" 
				 	value="<?php echo esc_attr( $this->value() ) ?>"
				 	placeholder="<?php echo $this->placeholder; ?>" 
				 	data-maxitem="<?php echo $this->final_max_item() ?>" <?php $this->link() ?> multiple>

					<?php 
					// rendering option
					if( is_array( $this->choices ) ):
						foreach ( $this->choices as $key => $value ):
							echo '<option value="'. $key .'">'. $value .'</option>';
						endforeach;
					endif; ?>
			</select>
		</div>

	<?php
	}
}