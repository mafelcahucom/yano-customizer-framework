<?php

/**
 * @package   Yano Customizer Framework
 * @author    Mafel John Timkang Cahucom
 * @license   https://www.gnu.org/licenses/gpl-2.0.html
 * @since     1.0
 */

namespace Field;

use Control\Yano_Tagging_Control;
use Field\Yano_Settings;

class Yano_Field_Tagging extends Yano_Settings {

	/**
	 * Rendering Tagging
	 *
	 * @access public
	 * @since 1.0.0
	 * @param object 	$wp_customize 	object from WP_Customize_Manager
	 * @param string 	$id 			slug or index id
	 * @param array  	$config 		list of configuration
	 * 
	 */
	public function render( $wp_customize, $config ) {

		// settings rules
		$rules = array(
			'label'			=> array(
				'rule'		=> 'empty',
				'default'	=> 'Tagging Field',
				'type'		=> 'string'
			),
			'description'	=> array(
				'rule'		=> 'empty',
				'default'	=> '',
				'type'		=> 'string'
			),
			'section'		=> array(
				'rule'		=> 'required',
				'default'	=> '',
				'type'		=> 'string'
			),
			'default'		=> array(
				'rule'		=> 'empty',
				'default'	=> '',
				'type'		=> 'array'
			),
			'priority'		=> array(
				'rule'		=> 'empty',
				'default'	=> '',
				'type'		=> 'number'
			),
			'maxitem'		=> array(
				'rule'		=> 'empty',
				'default'	=> 'none',
				'type'		=> 'number'
			),
			'placeholder'	=> array(
				'rule'		=> 'empty',
				'default'	=> '',
				'type'		=> 'string'
			),
			'active_callback' => array(
				'rule'		=> 'empty',
				'default'	=> '',
				'type'		=> 'any'
			)
		);

		// setting field name
		$field_name =  yano_error_field_name( 'tagging', $config['id'] );

		// sanitizing arguments
		$args = yano_sanitize_argument( $field_name, $config, $rules );

		if( is_array( $args ) && parent::sanitize_argument( $config, $field_name ) != false ) {

			// adding settings
			$this->init_settings( $wp_customize, $config, $field_name );

			// adding control
			$wp_customize->add_control( new Yano_Tagging_Control( $wp_customize, $args['id'] . '_field', array(
				'label'			=> esc_html( $args['label'] ),
				'description'	=> esc_html( $args['description'] ),
				'section'		=> $args['section'],
				'settings'		=> $args['id'],
				'priority'		=> $args['priority'],
				'maxitem'		=> $args['maxitem'],
				'placeholder'	=> $args['placeholder'],
				'active_callback' => $args['active_callback']
			)));
		}
	}
}