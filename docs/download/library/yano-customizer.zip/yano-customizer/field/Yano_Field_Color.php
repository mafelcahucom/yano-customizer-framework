<?php

/**
 * @package   Yano Customizer Framework
 * @author    Mafel John Timkang Cahucom
 * @license   https://www.gnu.org/licenses/gpl-2.0.html
 * @since     1.0
 */

namespace Field;

use Field\Yano_Settings;

class Yano_Field_Color extends Yano_Settings {

	private $args;

	/**
	 * Rendering Color Picker
	 *
	 * @access public
	 * @since 1.0.0
	 * @param object 	$wp_customize 	object from WP_Customize_Manager
	 * @param string 	$id 			slug or index id
	 * @param array  	$config 		list of configuration
	 * 
	 */
	public function render( $wp_customize, $config ) {
		// settings rules
		$rules = array(
			'label'			=> array(
				'rule'		=> 'empty',
				'default'	=> 'Color Field',
				'type'		=> 'string'
			),
			'description'	=> array(
				'rule'		=> 'empty',
				'default'	=> '',
				'type'		=> 'string'
			),
			'section'		=> array(
				'rule'		=> 'required',
				'default'	=> '',
				'type'		=> 'string'
			),
			'priority'		=> array(
				'rule'		=> 'empty',
				'default'	=> '',
				'type'		=> 'number'
			),
			'active_callback' => array(
				'rule'		=> 'empty',
				'default'	=> '',
				'type'		=> 'any'
			)
		);

		$field_name =  yano_error_field_name( 'color', $config['settings'] );

		$args = yano_sanitize_argument( $field_name, $config, $rules );

		if( is_array( $args ) && parent::sanitize_argument( $config, $field_name ) != false ) {

			// adding settings
			$this->init_settings( $wp_customize, $config, $field_name );

			// adding control
			$wp_customize->add_control( $args['settings'] . '_field', array(
				'type'			=> 'color',
				'label'			=> __( $args['label'] ),
				'description'	=> esc_html( $args['description'] ),
				'section'		=> $args['section'],
				'settings'		=> $args['settings'],
				'priority'		=> $args['priority'],
				'active_callback' => $args['active_callback']
			));
		}
	}

}
