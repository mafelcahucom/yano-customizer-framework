<?php

/**
 * @package   Yano Customizer Framework
 * @author    Mafel John Timkang Cahucom
 * @license   https://www.gnu.org/licenses/gpl-2.0.html
 * @since     1.0
 */

namespace Field;

use Control\Yano_Numeric_Control;
use Field\Yano_Settings;

class Yano_Field_Numeric extends Yano_Settings {

	/**
	 * Rendering Numeric
	 *
	 * @access public
	 * @since 1.0.0
	 * @param object 	$wp_customize 	object from WP_Customize_Manager
	 * @param string 	$id 			slug or index id
	 * @param array  	$config 		list of configuration
	 * 
	 */
	public function render( $wp_customize, $config ) {

		// settings rules
		$rules = array(
			'label'			=> array(
				'rule'		=> 'empty',
				'default'	=> 'Number Field',
				'type'		=> 'string'
			),
			'description'	=> array(
				'rule'		=> 'empty',
				'default'	=> '',
				'type'		=> 'string'
			),
			'section'		=> array(
				'rule'		=> 'required',
				'default'	=> '',
				'type'		=> 'string'
			),
			'default'		=> array(
				'rule'		=> 'empty',
				'default'	=> '',
				'type'		=> 'number'
			),
			'priority'		=> array(
				'rule'		=> 'empty',
				'default'	=> '',
				'type'		=> 'number'
			),
			'options'		=> array(
				'rule'		=> 'required',
				'default'	=> '',
				'type'		=> 'array'
			),
			'active_callback' => array(
				'rule'		=> 'empty',
				'default'	=> '',
				'type'		=> 'any'
			)
		);

		// setting field name
		$field_name =  yano_error_field_name( 'numeric', $config['id'] );

		// sanitizing arguments
		$args = yano_sanitize_argument( $field_name, $config, $rules );

		// validating option value
		$is_options_valid = $this->options_validation( $args['options'], $field_name );

		if( is_array( $args ) && parent::sanitize_argument( $config, $field_name ) != false && $is_options_valid == true ) {

			// adding settings
			$this->init_settings( $wp_customize, $config, $field_name );

			// adding control
			$wp_customize->add_control( new Yano_Numeric_Control( $wp_customize, $args['id'] . '_field', array(
				'label'			=> esc_html( $args['label'] ),
				'description'	=> esc_html( $args['description'] ),
				'section'		=> $args['section'],
				'settings'		=> $args['id'],
				'priority'		=> $args['priority'],
				'options'		=> $args['options'],
				'active_callback' => $args['active_callback']
			)));
		}
	}


	/**
	* Validating options in arguments
	*
	* @param array 		$options 		list of options
	* @param string 	$field 			name of field
	*/
	private function options_validation( $options, $field ) {

		$rules = array(
			'min'	=> array(
				'rule'		=> 'required',
				'default'	=> '',
				'type'		=> 'number'
			),
			'max'	=> array(
				'rule'		=> 'required',
				'default'	=> '',
				'type'		=> 'number'
			),
			'step'	=> array(
				'rule'		=> 'required',
				'default'	=> '',
				'type'		=> 'number'
			)
		);

		if( yano_check_arguments( $rules, $options, $field ) == true ) {
			if( $options['min'] >= $options['max'] ) {
				yano_alert_warning( 'Error 110: min must be less than max in field ' . yano_code( 'success', $field ) .'.' );
				return false;
			}elseif( $options['max'] <= $options['min'] ) {
				yano_alert_warning( 'Error 111: max must be greater than min in field ' . yano_code( 'success', $field ) .'.' );
				return false;
			}else{
				if( $options['step'] >= $options['max'] ) {
					yano_alert_warning( 'Error 112: step must be less than max in field ' . yano_code( 'success', $field ) .'.' );
					return false;
				}elseif( $options['step'] <= 0 ) {
					yano_alert_warning( 'Error 113: step must be greater than 0 in field ' . yano_code( 'success', $field ) .'.' );
					return false;
				}else{
					return true;
				}
			}
		}else{
			return false;
		}
	}
}