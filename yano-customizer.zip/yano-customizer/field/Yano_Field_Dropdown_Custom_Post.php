<?php

/**
 * @package   Yano Customizer Framework
 * @author    Mafel John Timkang Cahucom
 * @license   https://www.gnu.org/licenses/gpl-2.0.html
 * @since     1.0
 */
namespace Field;

use Control\Yano_Dropdown_Custom_Post_Control;
use Field\Yano_Settings;

class Yano_Field_Dropdown_Custom_Post extends Yano_Settings {

	/**
	 * Rendering Dropdown Custom Post
	 *
	 * @access public
	 * @since 1.0.0
	 * @param object 	$wp_customize 	object from WP_Customize_Manager
	 * @param string 	$id 			slug or index id
	 * @param array  	$config 		list of configuration
	 * 
	 */
	public function render( $wp_customize, $config ) {

		// settings rules
		$rules = array(
			'label'			=> array(
				'rule'		=> 'empty',
				'default'	=> 'Dropdown Custom Post Field',
				'type'		=> 'string'
			),
			'description'	=> array(
				'rule'		=> 'empty',
				'default'	=> '',
				'type'		=> 'string'
			),
			'section'		=> array(
				'rule'		=> 'required',
				'default'	=> '',
				'type'		=> 'string'
			),
			'default'		=> array(
				'rule'		=> 'empty',
				'default'	=> '',
				'type'		=> 'number'
			),
			'priority'		=> array(
				'rule'		=> 'empty',
				'default'	=> '',
				'type'		=> 'number'
			),
			'post_type'		=> array(
				'rule'		=> 'required',
				'default'	=> '',
				'type'		=> 'string'
			),
			'order'			=> array(
				'rule'		=> 'empty',
				'default'	=> '',
				'type'		=> 'string'
			),
			'active_callback' => array(
				'rule'		=> 'empty',
				'default'	=> '',
				'type'		=> 'any'
			)
		);

		// setting field name
		$field_name =  yano_error_field_name( 'dropdown-custom-post', $config['id'] );

		// sanitizing arguments
		$args = yano_sanitize_argument( $field_name, $config, $rules );

		// validating order and displaying error message
		$is_valid_order = yano_is_valid_argument_value([
			'value'		=> $args['order'],
			'valid'		=> [ 'asc', 'desc' ],
			'field'		=> $field_name,
			'allowed'	=> 'asc, desc',
			'argument'	=> 'order'
		]);

		if( is_array( $args ) && parent::sanitize_argument( $config, $field_name ) != false && $is_valid_order == true ) {

			// adding settings
			$this->init_settings( $wp_customize, $config, $field_name );
			
			// adding control
			$wp_customize->add_control( new Yano_Dropdown_Custom_Post_Control( $wp_customize, $args['id'] . '_field', array(
				'label'			=> esc_html( $args['label'] ),
				'description'	=> esc_html( $args['description'] ),
				'section'		=> $args['section'],
				'settings'		=> $args['id'],
				'priority'		=> $args['priority'],
				'post_type'		=> $args['post_type'],
				'order'			=> $args['order'],
				'active_callback' => $args['active_callback']
			)));
		}
	}
}