<?php

/**
 * @package   Yano Customizer Framework
 * @author    Mafel John Timkang Cahucom
 * @license   https://www.gnu.org/licenses/gpl-2.0.html
 * @since     1.0
 */

namespace Field;

use Control\Yano_Color_Picker_Control;
use Field\Yano_Settings;

class Yano_Field_Color_Picker extends Yano_Settings {

	/**
	 * Rendering Color Picker
	 *
	 * @access public
	 * @since 1.0.0
	 * @param object 	$wp_customize 	object from WP_Customize_Manager
	 * @param string 	$id 			slug or index id
	 * @param array  	$config 		list of configuration
	 * 
	 */
	public function render( $wp_customize, $config ) {

		// settings rules
		$rules = array(
			'label'			=> array(
				'rule'		=> 'empty',
				'default'	=> 'Color Picker Field',
				'type'		=> 'string'
			),
			'description'	=> array(
				'rule'		=> 'empty',
				'default'	=> '',
				'type'		=> 'string'
			),
			'section'		=> array(
				'rule'		=> 'required',
				'default'	=> '',
				'type'		=> 'string'
			),
			'priority'		=> array(
				'rule'		=> 'empty',
				'default'	=> '',
				'type'		=> 'number'
			),
			'default'		=> array(
				'rule'		=> 'empty',
				'default'	=> '',
				'type'		=> 'string'
			),
			'format'		=> array(
				'rule'		=> 'required',
				'default'	=> '',
				'type'		=> 'string'
			),
			'opacity'		=> array(
				'rule'		=> 'empty',
				'default'	=> '',
				'type'		=> 'boolean'
			),
			'active_callback' => array(
				'rule'		=> 'empty',
				'default'	=> '',
				'type'		=> 'any'
			)
		);

		// setting field name
		$field_name =  yano_error_field_name( 'color-picker', $config['id'] );

		// sanitizing arguments
		$args = yano_sanitize_argument( $field_name, $config, $rules );

		// validating format value and display error message
		$is_valid_format = yano_is_valid_argument_value([
			'value'		=> $args['format'],
			'valid'		=> [ 'hex', 'HEX', 'rgba', 'RGBA' ],
			'field'		=> $field_name,
			'allowed'	=> 'hex, rgba',
			'argument'	=> 'format'
		]);

		if( is_array( $args ) && parent::sanitize_argument( $config, $field_name ) != false && $is_valid_format == true ) {

			// adding settings
			$this->init_settings( $wp_customize, $config, $field_name );

			// adding control
			$wp_customize->add_control( new Yano_Color_Picker_Control( $wp_customize, $args['id'] . '_field', array(
				'label'			=> esc_html( $args['label'] ),
				'description'	=> esc_html( $args['description'] ),
				'section'		=> $args['section'],
				'settings'		=> $args['id'],
				'priority'		=> $args['priority'],
				'default'		=> ( $args['default'] ? $args['default'] : 'transparent' ),
				'format'		=> $args['format'],
				'opacity'		=> $args['opacity'],
				'active_callback' => $args['active_callback']
			)));
		}
	}
}