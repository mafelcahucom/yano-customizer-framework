<?php

/**
 * @package   Yano Customizer Framework
 * @author    Mafel John Timkang Cahucom
 * @license   https://www.gnu.org/licenses/gpl-2.0.html
 * @since     1.0
 */

namespace Control;


class Yano_Color_Set_Control extends \WP_Customize_Control {


	/**
	 * The type of this control
	 * @var string
	 */
	public $type = 'color-set';

	/**
	 * The set of colors
	 * @var array
	 */
	public $colors;

	/**
	 * The default value
	 * @var string
	 */
	public $default;

	/**
	 * The shape of color
	 * @var string
	 */
	public $shape;

	/**
	 * The size of colors
	 * @var integer
	 */
	public $size;


	/**
	 * Return the color label value
	 * @return string
	 */
	private function color_value() {
		if( $this->value() == $this->default ) {
			$output = $this->value();
		}else{
			$output = $this->value();
		}

		return $output;
	}


	/**
	 * Validate the value of shape property
	 * @return string
	 */
	private function shape_value() {
		if( ! empty( $this->shape ) ) {
			if( $this->shape == 'square' ) {
				$output = 'square';
			}elseif( $this->shape == 'circle' ) {
				$output = 'circle';
			}else{
				$output = 'square';
			}
		}else {
			$output = 'square';
		}

		return $output;
	}

	/**
	 * Return the value of size with pixel unit
	 * @return string;
	 */
	private function size_value() {
		if( ! empty( $this->size ) ) {
			$output = $this->size;
		}else{
			$output = 20;
		}

		return $output . 'px';
	}

	/**
	 * Return the id with extension index for uniqueness
	 * @return string
	 */
	private function color_id( $index ) {
		$output = $this->id . '-' . $index;
		return $output;
	}

	/**
	 * Validate if the value is select during document load
	 * @return string
	 */
	private function is_selected( $value ) {
		if( $this->color_value() == $value ) {
			return 'selected';
		}
	}


	/**
	 * Render the content and display in frontend
	 * @return html    control in customizer page
	 */
	public function render_content() {
	?>

		<label>
			<?php if( ! empty( $this->label ) ): ?>
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			<?php endif; ?>

			<?php if( ! empty( $this->description ) ): ?>
				<span class="description customize-control-description"><?php echo wp_kses_post( $this->description ); ?></span>
			<?php endif; ?>
		</label>

		<input type="text" 
				class="yano-color-set"
				id="<?php echo esc_attr( $this->id ) ?>" 
				name="<?php echo esc_attr( $this->id ) ?>"
				value="<?php echo esc_attr( $value ) ?>"
				hidden="hidden"
				<?php echo $this->link(); ?>>

		<div class="yano-accordion yano-color-set-parent">
			<div class="yano-accordion-head" data-state="close">
				<div class="yano-accordion-flex">
					<div class="yano-accordion-title">
						<div id="<?php echo esc_attr( $this->id ) ?>-color-preview" 
							 class="yano-color-set-color-preview <?php echo esc_attr( $this->shape_value() ) ?>"
							 style="background-color: <?php echo $this->color_value(); ?>"></div>
						<h3 id="<?php echo esc_attr( $this->id ) ?>-color-label" 
							class="yano-color-set-color-label"><?php echo $this->color_value(); ?></h3>
					</div>
					<i class="dashicons dashicons-arrow-down yano-accordion-arrow-down"></i>
					<i class="dashicons dashicons-arrow-up yano-accordion-arrow-up"></i>
				</div>
			</div>
			<div class="yano-accordion-body">
				<div class="yano-accordion-body-content">
					
					<div class="yano-color-set-body-overflow">
						<div class="yano-color-set-body">
							<?php if( ! empty( $this->colors ) ): ?>
									<?php foreach ( $this->colors as $key => $value ): ?>

										<div  class="yano-color-set-colors-container <?php echo esc_attr( $this->id ) ?>-container <?php echo esc_attr( $this->shape_value() ) ?> <?php echo $this->is_selected( $value ) ?>" 
											  data-color="<?php echo esc_attr( $value ) ?>"
											  data-current_color="<?php echo esc_attr( $this->color_value() ) ?>"
											  data-target_id="<?php echo esc_attr( $this->id ) ?>"
											  style="width: <?php echo esc_attr( $this->size_value() ) ?>; height: <?php echo esc_attr( $this->size_value() ) ?>;">
											<div class="yano-color-set-color"style="background-color: <?php echo esc_attr( $value ) ?>"></div>
										</div>

									<?php endforeach; ?>
							<?php endif; ?>
							
							<!-- Hidden Component -->
							<div class="yano-hidden-component <?php echo esc_attr( $this->shape_value() )?>" style="width: <?php echo esc_attr( $this->size_value() ) ?>"></div>
							<div class="yano-hidden-component <?php echo esc_attr( $this->shape_value() )?>" style="width: <?php echo esc_attr( $this->size_value() ) ?>"></div>
							<div class="yano-hidden-component <?php echo esc_attr( $this->shape_value() )?>" style="width: <?php echo esc_attr( $this->size_value() ) ?>"></div>
							<div class="yano-hidden-component <?php echo esc_attr( $this->shape_value() )?>" style="width: <?php echo esc_attr( $this->size_value() ) ?>"></div>
							<div class="yano-hidden-component <?php echo esc_attr( $this->shape_value() )?>" style="width: <?php echo esc_attr( $this->size_value() ) ?>"></div>
							<div class="yano-hidden-component <?php echo esc_attr( $this->shape_value() )?>" style="width: <?php echo esc_attr( $this->size_value() ) ?>"></div>
							<div class="yano-hidden-component <?php echo esc_attr( $this->shape_value() )?>" style="width: <?php echo esc_attr( $this->size_value() ) ?>"></div>
							<div class="yano-hidden-component <?php echo esc_attr( $this->shape_value() )?>" style="width: <?php echo esc_attr( $this->size_value() ) ?>"></div>
							<div class="yano-hidden-component <?php echo esc_attr( $this->shape_value() )?>" style="width: <?php echo esc_attr( $this->size_value() ) ?>"></div>
							<div class="yano-hidden-component <?php echo esc_attr( $this->shape_value() )?>" style="width: <?php echo esc_attr( $this->size_value() ) ?>"></div>
							<div class="yano-hidden-component <?php echo esc_attr( $this->shape_value() )?>" style="width: <?php echo esc_attr( $this->size_value() ) ?>"></div>
							<div class="yano-hidden-component <?php echo esc_attr( $this->shape_value() )?>" style="width: <?php echo esc_attr( $this->size_value() ) ?>"></div>
							<div class="yano-hidden-component <?php echo esc_attr( $this->shape_value() )?>" style="width: <?php echo esc_attr( $this->size_value() ) ?>"></div>
							<div class="yano-hidden-component <?php echo esc_attr( $this->shape_value() )?>" style="width: <?php echo esc_attr( $this->size_value() ) ?>"></div>
							<div class="yano-hidden-component <?php echo esc_attr( $this->shape_value() )?>" style="width: <?php echo esc_attr( $this->size_value() ) ?>"></div>
							<div class="yano-hidden-component <?php echo esc_attr( $this->shape_value() )?>" style="width: <?php echo esc_attr( $this->size_value() ) ?>"></div>
							<div class="yano-hidden-component <?php echo esc_attr( $this->shape_value() )?>" style="width: <?php echo esc_attr( $this->size_value() ) ?>"></div>
							<div class="yano-hidden-component <?php echo esc_attr( $this->shape_value() )?>" style="width: <?php echo esc_attr( $this->size_value() ) ?>"></div>
							<div class="yano-hidden-component <?php echo esc_attr( $this->shape_value() )?>" style="width: <?php echo esc_attr( $this->size_value() ) ?>"></div>
							<div class="yano-hidden-component <?php echo esc_attr( $this->shape_value() )?>" style="width: <?php echo esc_attr( $this->size_value() ) ?>"></div>
							<!-- End Hidden Component -->

						</div>
					</div>

				</div>
				<div class="yano-accordion-body-footer">
					<button class="button-secondary yano-color-set-btn-default" 
							data-target_preview="<?php echo esc_attr( $this->id ) ?>-color-preview"
							data-target_id="<?php echo esc_attr( $this->id ) ?>"
							data-default_value="<?php echo esc_attr( $this->default ) ?>">Default</button>
				</div>
			</div>
		</div>

	<?php
	}
}