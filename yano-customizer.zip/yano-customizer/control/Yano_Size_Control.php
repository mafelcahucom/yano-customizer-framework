<?php

/**
 * @package   Yano Customizer Framework
 * @author    Mafel John Timkang Cahucom
 * @license   https://www.gnu.org/licenses/gpl-2.0.html
 * @since     1.0
 */

namespace Control;


class Yano_Size_Control extends \WP_Customize_Control {

	/**
	 * List of format allowed
	 * @var string | int
	 */
	public $units;


	/**
	 * Holds the placeholder
	 * @var string	 
	 * */
	public $placeholder;


	/**
	 * Render the content and display in frontend
	 * @return html    control in customizer page
	 */
	public function render_content() {
	?>
		
		<div class="yano-size-parent">
			<label>
				<?php if( ! empty( $this->label ) ): ?>
					<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				<?php endif; ?>

				<?php if( ! empty( $this->description ) ): ?>
					<span class="description customize-control-description"><?php echo wp_kses_post( $this->description ); ?></span>
				<?php endif; ?>
			</label>
		
			<input type="hidden" 
				   id="<?php echo esc_attr( $this->id ); ?>" 
				   class="yano-size" 
				   value="<?php echo esc_attr( $this->value() ); ?>" 
				   <?php $this->link(); ?>>

			<input type="text" 
				   id="<?php echo esc_attr( $this->id ); ?>-mirror" 
				   class="yano-size-mirror" 
				   value="<?php echo esc_attr( $this->value() ); ?>" 
				   placeholder="<?php echo esc_attr( $this->placeholder ); ?>" 
				   data-units="<?php echo esc_attr( $this->data_unit() ); ?>">
	
		</div>

	<?php
	}


	/**
	 * Return unit array to single string
	 *
	 * @param array 		$units  	list of units
	 * @return string 		imploded value of $units array
	 */
	private function data_unit() {
		if( ! empty( $this->units ) ) {
			return implode( ',', $this->units );
		}
	}
}